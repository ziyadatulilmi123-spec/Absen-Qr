<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input & Kelola Nilai Santri - Pondok Pesantren Ziyadatul Ilmi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 text-gray-800">

    <!-- Navbar -->
    <nav class="bg-[#004d25] text-white shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-16">
            <div class="flex items-center space-x-3">
                <a href="<?php echo e(route('home')); ?>" class="font-bold text-lg hover:text-yellow-300 transition flex items-center gap-2">
                    <i class="fa-solid fa-mosque"></i> Pondok Pesantren Ziyadatul Ilmi
                </a>
            </div>
            <div class="flex items-center space-x-4 text-sm">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-yellow-300 transition flex items-center gap-1">
                    <i class="fa-solid fa-house"></i> Beranda
                </a>
                <a href="<?php echo e(route('absensi')); ?>" class="hover:text-yellow-300 transition flex items-center gap-1">
                    <i class="fa-solid fa-calendar-check"></i> Absensi
                </a>
                <a href="<?php echo e(route('nilai')); ?>" class="text-yellow-300 font-bold transition flex items-center gap-1">
                    <i class="fa-solid fa-graduation-cap"></i> Ujian & Nilai
                </a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="bg-yellow-400 text-[#004d25] font-bold px-3 py-1.5 rounded-lg text-xs hover:bg-yellow-300 transition">
                        Dashboard Admin
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="bg-yellow-400 text-[#004d25] font-bold px-3 py-1.5 rounded-lg text-xs hover:bg-yellow-300 transition">
                        Login Admin
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-4 py-8">
        
        <!-- Header Page -->
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
                    <i class="fa-solid fa-graduation-cap text-[#004d25]"></i> Kelola Ujian & Nilai Santri
                </h1>
                <p class="text-gray-500 text-sm mt-1">Ketik nama mata pelajaran dan masukkan nilai ujian santri.</p>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-6 p-4 bg-green-100 border border-green-300 text-green-800 rounded-xl text-sm flex items-center gap-2">
                <i class="fa-solid fa-circle-check text-green-600"></i> <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
        <!-- Form Input Nilai (Manual Text Input) -->
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-8">
            <h2 class="text-lg font-bold text-gray-800 mb-4 pb-2 border-b flex items-center gap-2">
                <i class="fa-solid fa-pen-to-square text-[#004d25]"></i> Form Input Nilai Siswa
            </h2>

            <form action="<?php echo e(route('nilai.store')); ?>" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <!-- Pilih Siswa -->
                    <div>
                        <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Pilih Santri / Siswa</label>
                        <select name="siswa_id" required class="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-[#004d25] focus:outline-none bg-white">
                            <option value="">-- Pilih Santri --</option>
                            <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($siswa->id); ?>"><?php echo e($siswa->nama); ?> (<?php echo e($siswa->kelas); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Input Teks Mata Pelajaran (Ketik Manual) -->
                    <div>
                        <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Mata Pelajaran</label>
                        <input type="text" name="mata_pelajaran" placeholder="Contoh: Pendidikan Agama Islam / Matematika" required class="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-[#004d25] focus:outline-none">
                    </div>

                    <!-- Jenis Ujian -->
                    <div>
                        <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Jenis Ujian</label>
                        <select name="jenis_ujian" required class="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-[#004d25] focus:outline-none bg-white">
                            <option value="UTS">UTS / ASTS</option>
                            <option value="UAS">UAS / ASAS</option>
                            <option value="Ulangan Harian">Ulangan Harian</option>
                            <option value="Tugas">Tugas</option>
                        </select>
                    </div>

                    <!-- Nilai -->
                    <div>
                        <label class="block text-xs font-bold text-gray-700 uppercase mb-1">Nilai (0-100)</label>
                        <input type="number" name="nilai" min="0" max="100" placeholder="85" required class="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-[#004d25] focus:outline-none">
                    </div>

                </div>

                <div class="mt-4 text-right">
                    <button type="submit" class="bg-[#004d25] hover:bg-[#00381b] text-white font-bold px-6 py-2.5 rounded-xl text-sm transition shadow-sm inline-flex items-center gap-2">
                        <i class="fa-solid fa-floppy-disk"></i> Simpan Nilai
                    </button>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- Daftar Nilai Terinput & Pilihan E-Raport -->
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 class="text-lg font-bold text-gray-800 mb-4 pb-2 border-b flex items-center gap-2">
                <i class="fa-solid fa-list-check text-[#004d25]"></i> Daftar Santri & E-Raport Digital
            </h2>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm border-collapse">
                    <thead>
                        <tr class="bg-gray-100 text-gray-700 border-b">
                            <th class="p-3">No</th>
                            <th class="p-3">Nama Santri</th>
                            <th class="p-3">Kelas</th>
                            <th class="p-3 text-center">E-Raport Digital</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="p-3 font-medium text-gray-500"><?php echo e($idx + 1); ?></td>
                                <td class="p-3 font-semibold text-gray-800"><?php echo e($siswa->nama); ?></td>
                                <td class="p-3 text-gray-600"><?php echo e($siswa->kelas); ?></td>
                                <td class="p-3 text-center">
                                    <a href="<?php echo e(route('raport.show', $siswa->id)); ?>" class="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 transition shadow-sm">
                                        <i class="fa-solid fa-file-invoice"></i> Lihat Raport
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="p-4 text-center text-gray-400 italic">Belum ada data santri.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\web resmi zi\ziyadatulilmi\resources\views/nilai.blade.php ENDPATH**/ ?>